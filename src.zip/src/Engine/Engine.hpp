#pragma once
#include <SDL.h>
#include <GL/glew.h>

namespace Engine
{
    int Init();
} // end of Engine namespace