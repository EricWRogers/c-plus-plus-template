#pragma once

namespace Engine
{
    struct GLTexture
    {
        unsigned int id;
        int width;
        int height;
    };
}